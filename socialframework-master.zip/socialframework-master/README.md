socialframework
===============

Social Framework Reference for iOS 6

v1.0 - 
Covers Twitter (posting and retrieval methods)
Covers Facebook (posting and retrieval methods)
