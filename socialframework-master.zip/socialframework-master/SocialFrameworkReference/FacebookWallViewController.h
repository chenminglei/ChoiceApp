//
//  FacebookWallViewController.h
//  SocialFrameworkReference
//
//  Created by Stuart G Breckenridge on 15/10/2012.
//  Copyright (c) 2012 Stuart G Breckenridge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FacebookWallViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>

@end
