//
//  AppDelegate.h
//  SocialFrameworkReference
//
//  Created by Stuart G Breckenridge on 07/10/2012.
//  Copyright (c) 2012 Stuart G Breckenridge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
