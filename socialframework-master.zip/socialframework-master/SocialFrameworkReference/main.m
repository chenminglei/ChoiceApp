//
//  main.m
//  SocialFrameworkReference
//
//  Created by Stuart G Breckenridge on 07/10/2012.
//  Copyright (c) 2012 Stuart G Breckenridge. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
