//
//  FacebookDetailViewController.h
//  SocialFrameworkReference
//
//  Created by Stuart G Breckenridge on 14/10/2012.
//  Copyright (c) 2012 Stuart G Breckenridge. All rights reserved.
//

//  This controller looks after the 

#import <UIKit/UIKit.h>

@interface FacebookDetailViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>



@end
